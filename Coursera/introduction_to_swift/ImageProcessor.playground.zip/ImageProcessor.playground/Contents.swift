////: Playground - noun: a place where people can play
//
import UIKit

let image = UIImage(named: "sample")

// Process the image!
let imageProcessor = ImageProcessor()!

// Default with String parameters

// Blur Filter
//let blurImage = imageProcessor.filter(image!, filterName: Filter.BLUR)

// Gray Filter
//let grayImage = imageProcessor.filter(image!, filterName: Filter.GRAY)

// Motion Filter
//let motionImage = imageProcessor.filter(image!, filterName: Filter.MOTION)

// BRIGHNEST Filter
//let brightImage = imageProcessor.filter(image!, filterName: Filter.BRIGHTNESS)

// CONTRAST Filter
//let contrastImage = imageProcessor.filter(image!, filterName: Filter.CONTRAST)

// Custom filters

// Blur Filter
let blurFilter = BlurFilter()!
blurFilter.setBlurSize(5)
let customBlurImage = imageProcessor.filter(image!, filter: blurFilter)

// Multiply Filter

imageProcessor.clearListFilter()
imageProcessor.insertFilter(blurFilter)
imageProcessor.insertFilter(MotionFilter()!)

let multiplyImage = imageProcessor.applyListFilter(image!)

